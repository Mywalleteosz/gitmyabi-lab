# gitmyabi-lab

Auto-generated TypeScript type bindings for **gitmyabi-lab**

- **Target**: `viem`
- **Contracts**: 1

## Installation

```bash
npm install gitmyabi-lab@1.0.0
```

## Usage

### Class-based API (TypeChain-like)

```typescript
import { createPublicClient, createWalletClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { YourContract } from 'gitmyabi-lab';

const publicClient = createPublicClient({ chain: mainnet, transport: http() });
const walletClient = createWalletClient({ chain: mainnet, transport: http() });

// Create contract instance
const contract = new YourContract('0x...', { publicClient, walletClient });

// Read functions - call directly like TypeChain!
const result = await contract.yourMethod(param1, param2);

// Write functions - also call directly!
const hash = await contract.transfer('0x...', 1000n);
```

### With viem directly

```typescript
import { createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { YourContractAbi } from 'gitmyabi-lab';

const client = createPublicClient({
  chain: mainnet,
  transport: http(),
});

// Fully typed contract read
const result = await client.readContract({
  address: '0x...',
  abi: YourContractAbi,
  functionName: 'yourMethod',
  args: [param1, param2],
});

// Fully typed contract write
const hash = await client.writeContract({
  address: '0x...',
  abi: YourContractAbi,
  functionName: 'yourMethod',
  args: [param1, param2],
});
```

### With wagmi

```typescript
import { useReadContract, useWriteContract } from 'wagmi';
import { YourContractAbi } from 'gitmyabi-lab';

function MyComponent() {
  const { data } = useReadContract({
    address: '0x...',
    abi: YourContractAbi,
    functionName: 'yourMethod',
    args: [param1, param2],
  });

  const { writeContract } = useWriteContract();
  
  const handleWrite = () => {
    writeContract({
      address: '0x...',
      abi: YourContractAbi,
      functionName: 'yourMethod',
      args: [param1, param2],
    });
  };

  return <button onClick={handleWrite}>Call Contract</button>;
}
```

## Type Safety

This package provides full TypeScript type safety for all contract methods, events, and parameters using viem's type system. All ABIs are exported as `const` assertions for maximum type inference.

## Generated Contracts

This package includes type bindings for 1 contract(s) generated from ABI artifacts.

## License

Apache License 2.0
