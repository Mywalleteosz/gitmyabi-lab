"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimpleStorage = exports.SimpleStorageAbi = void 0;
// Auto-generated exports for all contracts
var SimpleStorage_1 = require("./SimpleStorage");
Object.defineProperty(exports, "SimpleStorageAbi", { enumerable: true, get: function () { return SimpleStorage_1.SimpleStorageAbi; } });
Object.defineProperty(exports, "SimpleStorage", { enumerable: true, get: function () { return SimpleStorage_1.SimpleStorage; } });
