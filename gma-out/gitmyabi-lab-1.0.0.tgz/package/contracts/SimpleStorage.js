"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimpleStorage = exports.SimpleStorageAbi = void 0;
const viem_1 = require("viem");
/**
 * SimpleStorage ABI
 *
 * This ABI is typed using viem's type system for full type safety.
 */
exports.SimpleStorageAbi = [
    {
        "type": "function",
        "name": "get",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "set",
        "inputs": [
            {
                "name": "value",
                "type": "uint256"
            }
        ],
        "outputs": [],
        "stateMutability": "nonpayable"
    }
];
/**
 * SimpleStorage Contract Class
 *
 * Provides a class-based API similar to TypeChain for interacting with the contract.
 *
 * @example
 * ```typescript
 * import { createPublicClient, createWalletClient, http } from 'viem';
 * import { mainnet } from 'viem/chains';
 * import { SimpleStorage } from 'SimpleStorage';
 *
 * const publicClient = createPublicClient({ chain: mainnet, transport: http() });
 * const walletClient = createWalletClient({ chain: mainnet, transport: http() });
 *
 * const contract = new SimpleStorage('0x...', { publicClient, walletClient });
 *
 * // Read functions
 * const result = await contract.balanceOf('0x...');
 *
 * // Write functions
 * const hash = await contract.transfer('0x...', 1000n);
 *
 * // Simulate transactions (dry-run)
 * const simulation = await contract.simulate.transfer('0x...', 1000n);
 * console.log('Gas estimate:', simulation.request.gas);
 *
 * // Watch events
 * const unwatch = contract.watch.Transfer((event) => {
 *   console.log('Transfer event:', event);
 * });
 * ```
 */
class SimpleStorage {
    constructor(address, clients) {
        this.contractAddress = address;
        this.publicClient = clients.publicClient;
        this.contract = (0, viem_1.getContract)({
            address,
            abi: exports.SimpleStorageAbi,
            client: {
                public: clients.publicClient,
                wallet: clients.walletClient,
            },
        });
    }
    /**
     * Get the contract address
     */
    get address() {
        return this.contractAddress;
    }
    /**
     * Get the underlying viem contract instance.
     */
    getContract() {
        return this.contract;
    }
    /**
     * get
     * view
     */
    async get() {
        return this.contract.read.get();
    }
    /**
     * set
     * nonpayable
     * @param options Optional transaction parameters (value, gas, nonce, etc.)
     */
    async set(value, options) {
        if (!this.contract.write) {
            throw new Error('Wallet client is required for write operations');
        }
        return this.contract.write.set([value], options);
    }
    /**
     * Simulate contract write operations (dry-run without sending transaction)
     *
     * @example
     * const result = await contract.simulate.transfer('0x...', 1000n);
     * console.log('Gas estimate:', result.request.gas);
     * console.log('Would succeed:', result.result);
     */
    get simulate() {
        const contract = this.contract;
        if (!contract.simulate) {
            throw new Error('Public client is required for simulation');
        }
        return {
            /**
             * Simulate set
             * Returns gas estimate and result without sending transaction
             * @param options Optional transaction parameters (value, gas, nonce, etc.)
             */
            async set(value, options) {
                return contract.simulate.set([value], options);
            }
        };
    }
    /**
     * Watch contract events
     *
     * Note: This contract has no events, so watch returns an empty object.
     */
    get watch() {
        return {};
    }
}
exports.SimpleStorage = SimpleStorage;
