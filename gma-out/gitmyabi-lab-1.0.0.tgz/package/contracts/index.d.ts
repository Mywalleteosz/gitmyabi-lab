export { SimpleStorageAbi, SimpleStorage } from './SimpleStorage';
export type { SimpleStorageAbi as SimpleStorageAbiType, SimpleStorageContract } from './SimpleStorage';
