import type { Abi, Address, PublicClient, WalletClient, GetContractReturnType } from 'viem';
import { getContract } from 'viem';

/**
 * SimpleStorage ABI
 * 
 * This ABI is typed using viem's type system for full type safety.
 */
export const SimpleStorageAbi = [
  {
    "type": "function",
    "name": "get",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view"
  },
  {
    "type": "function",
    "name": "set",
    "inputs": [
      {
        "name": "value",
        "type": "uint256"
      }
    ],
    "outputs": [],
    "stateMutability": "nonpayable"
  }
] as const satisfies Abi;

/**
 * Type-safe ABI for SimpleStorage
 */
export type SimpleStorageAbi = typeof SimpleStorageAbi;

/**
 * Contract instance type for SimpleStorage
 */
// Use any for contract type to avoid complex viem type issues
// The runtime behavior is type-safe through viem's ABI typing
export type SimpleStorageContract = any;

/**
 * SimpleStorage Contract Class
 * 
 * Provides a class-based API similar to TypeChain for interacting with the contract.
 * 
 * @example
 * ```typescript
 * import { createPublicClient, createWalletClient, http } from 'viem';
 * import { mainnet } from 'viem/chains';
 * import { SimpleStorage } from 'SimpleStorage';
 * 
 * const publicClient = createPublicClient({ chain: mainnet, transport: http() });
 * const walletClient = createWalletClient({ chain: mainnet, transport: http() });
 * 
 * const contract = new SimpleStorage('0x...', { publicClient, walletClient });
 * 
 * // Read functions
 * const result = await contract.balanceOf('0x...');
 * 
 * // Write functions
 * const hash = await contract.transfer('0x...', 1000n);
 * 
 * // Simulate transactions (dry-run)
 * const simulation = await contract.simulate.transfer('0x...', 1000n);
 * console.log('Gas estimate:', simulation.request.gas);
 * 
 * // Watch events
 * const unwatch = contract.watch.Transfer((event) => {
 *   console.log('Transfer event:', event);
 * });
 * ```
 */
export class SimpleStorage {
  private contract: SimpleStorageContract;
  private contractAddress: Address;
  private publicClient: PublicClient;

  constructor(
    address: Address,
    clients: {
      publicClient: PublicClient;
      walletClient?: WalletClient;
    }
  ) {
    this.contractAddress = address;
    this.publicClient = clients.publicClient;
    this.contract = getContract({
      address,
      abi: SimpleStorageAbi,
      client: {
        public: clients.publicClient,
        wallet: clients.walletClient,
      },
    });
  }

  /**
   * Get the contract address
   */
  get address(): Address {
    return this.contractAddress;
  }

  /**
   * Get the underlying viem contract instance.
   */
  getContract(): SimpleStorageContract {
    return this.contract;
  }

  /**
   * get
   * view
   */
  async get(): Promise<bigint> {
    return this.contract.read.get() as Promise<bigint>;
  }

  /**
   * set
   * nonpayable
   * @param options Optional transaction parameters (value, gas, nonce, etc.)
   */
  async set(value: bigint, options?: {
    accessList?: import('viem').AccessList;
    authorizationList?: import('viem').AuthorizationList;
    chain?: import('viem').Chain | null;
    dataSuffix?: `0x${string}`;
    gas?: bigint;
    gasPrice?: bigint;
    maxFeePerGas?: bigint;
    maxPriorityFeePerGas?: bigint;
    nonce?: number;
    value?: bigint;
  }): Promise<`0x${string}`> {
    if (!this.contract.write) {
      throw new Error('Wallet client is required for write operations');
    }
    return this.contract.write.set([value] as const, options) as Promise<`0x${string}`>;
  }



  /**
   * Simulate contract write operations (dry-run without sending transaction)
   * 
   * @example
   * const result = await contract.simulate.transfer('0x...', 1000n);
   * console.log('Gas estimate:', result.request.gas);
   * console.log('Would succeed:', result.result);
   */
  get simulate() {
    const contract = this.contract;
    if (!contract.simulate) {
      throw new Error('Public client is required for simulation');
    }
    return {
      /**
       * Simulate set
       * Returns gas estimate and result without sending transaction
       * @param options Optional transaction parameters (value, gas, nonce, etc.)
       */
      async set(value: bigint, options?: {
        accessList?: import('viem').AccessList;
        authorizationList?: import('viem').AuthorizationList;
        chain?: import('viem').Chain | null;
        dataSuffix?: `0x${string}`;
        gas?: bigint;
        gasPrice?: bigint;
        maxFeePerGas?: bigint;
        maxPriorityFeePerGas?: bigint;
        nonce?: number;
        value?: bigint;
      }): Promise<void> {
        return contract.simulate.set([value] as const, options) as Promise<void>;
      }
    };
  }

  /**
   * Watch contract events
   * 
   * Note: This contract has no events, so watch returns an empty object.
   */
  get watch() {
    return {};
  }
}
