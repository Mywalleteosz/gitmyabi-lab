import type { Address, PublicClient, WalletClient } from 'viem';
/**
 * SimpleStorage ABI
 *
 * This ABI is typed using viem's type system for full type safety.
 */
export declare const SimpleStorageAbi: readonly [{
    readonly type: "function";
    readonly name: "get";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "set";
    readonly inputs: readonly [{
        readonly name: "value";
        readonly type: "uint256";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}];
/**
 * Type-safe ABI for SimpleStorage
 */
export type SimpleStorageAbi = typeof SimpleStorageAbi;
/**
 * Contract instance type for SimpleStorage
 */
export type SimpleStorageContract = any;
/**
 * SimpleStorage Contract Class
 *
 * Provides a class-based API similar to TypeChain for interacting with the contract.
 *
 * @example
 * ```typescript
 * import { createPublicClient, createWalletClient, http } from 'viem';
 * import { mainnet } from 'viem/chains';
 * import { SimpleStorage } from 'SimpleStorage';
 *
 * const publicClient = createPublicClient({ chain: mainnet, transport: http() });
 * const walletClient = createWalletClient({ chain: mainnet, transport: http() });
 *
 * const contract = new SimpleStorage('0x...', { publicClient, walletClient });
 *
 * // Read functions
 * const result = await contract.balanceOf('0x...');
 *
 * // Write functions
 * const hash = await contract.transfer('0x...', 1000n);
 *
 * // Simulate transactions (dry-run)
 * const simulation = await contract.simulate.transfer('0x...', 1000n);
 * console.log('Gas estimate:', simulation.request.gas);
 *
 * // Watch events
 * const unwatch = contract.watch.Transfer((event) => {
 *   console.log('Transfer event:', event);
 * });
 * ```
 */
export declare class SimpleStorage {
    private contract;
    private contractAddress;
    private publicClient;
    constructor(address: Address, clients: {
        publicClient: PublicClient;
        walletClient?: WalletClient;
    });
    /**
     * Get the contract address
     */
    get address(): Address;
    /**
     * Get the underlying viem contract instance.
     */
    getContract(): SimpleStorageContract;
    /**
     * get
     * view
     */
    get(): Promise<bigint>;
    /**
     * set
     * nonpayable
     * @param options Optional transaction parameters (value, gas, nonce, etc.)
     */
    set(value: bigint, options?: {
        accessList?: import('viem').AccessList;
        authorizationList?: import('viem').AuthorizationList;
        chain?: import('viem').Chain | null;
        dataSuffix?: `0x${string}`;
        gas?: bigint;
        gasPrice?: bigint;
        maxFeePerGas?: bigint;
        maxPriorityFeePerGas?: bigint;
        nonce?: number;
        value?: bigint;
    }): Promise<`0x${string}`>;
    /**
     * Simulate contract write operations (dry-run without sending transaction)
     *
     * @example
     * const result = await contract.simulate.transfer('0x...', 1000n);
     * console.log('Gas estimate:', result.request.gas);
     * console.log('Would succeed:', result.result);
     */
    get simulate(): {
        /**
         * Simulate set
         * Returns gas estimate and result without sending transaction
         * @param options Optional transaction parameters (value, gas, nonce, etc.)
         */
        set(value: bigint, options?: {
            accessList?: import("viem").AccessList;
            authorizationList?: import("viem").AuthorizationList;
            chain?: import("viem").Chain | null;
            dataSuffix?: `0x${string}`;
            gas?: bigint;
            gasPrice?: bigint;
            maxFeePerGas?: bigint;
            maxPriorityFeePerGas?: bigint;
            nonce?: number;
            value?: bigint;
        }): Promise<void>;
    };
    /**
     * Watch contract events
     *
     * Note: This contract has no events, so watch returns an empty object.
     */
    get watch(): {};
}
